from django.apps import AppConfig


class GasappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "gasapp"

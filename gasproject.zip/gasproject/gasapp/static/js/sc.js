let english = document.getElementById('home-english');
let hindi = document.getElementById('home-hindi');

hindi.style.display = 'none'; 

let btn = document.getElementById('language-btn');

btn.addEventListener('click', () => {
    if (hindi.style.display === 'none') {
        hindi.style.display = 'block'; 
        english.style.display = 'none'; 
    } else {
        hindi.style.display = 'none';
        english.style.display = 'block'; 
    }
});
